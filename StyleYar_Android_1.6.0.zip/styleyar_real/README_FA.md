# استایل‌یار — Android 1.0 + Backend AI/Commerce

این نسخه نسبت به پروتوتایپ قبلی یک لایه واقعی Backend اضافه دارد.

## قابلیت‌های متصل‌شده
- ارسال تصویر لباس از Android به Backend
- تحلیل لباس از طریق provider قابل تنظیم AI؛ حالت پیش‌فرض mock و حالت OpenAI با کلید سرور
- ذخیره لباس در SQLite
- تولید استایل از API
- ثبت Like/Dislike و دلیل رد پیشنهاد
- کاتالوگ فروشگاه‌ها و محصولات
- لینک ارجاع `/go/...` برای ثبت کلیک
- API ثبت فروشگاه و محصول

## اجرا

### Backend

```bash
cd backend
python -m venv .venv
# فعال‌سازی محیط مجازی
pip install -r requirements.txt
cp .env.example .env
uvicorn app.main:app --host 0.0.0.0 --port 8000
```

### AI واقعی

در `.env`:

```text
AI_PROVIDER=openai
OPENAI_API_KEY=YOUR_SERVER_SIDE_KEY
OPENAI_MODEL=gpt-5.6-luna
```

کلید API را هرگز داخل APK قرار ندهید. مدل‌های OpenAI فعلی از ورودی متن و تصویر پشتیبانی می‌کنند و از طریق Responses API قابل استفاده‌اند. citeturn1search0

### Android

پروژه را در Android Studio باز کنید و Gradle Sync سپس Run/Build را اجرا کنید.

برای Emulator آدرس API روی `http://10.0.2.2:8000` تنظیم شده است. برای گوشی واقعی، آدرس سرور را در `localStorage` با کلید `styleyar_api` یا در کد frontend به آدرس HTTPS سرور تغییر دهید.

## وضعیت فعلی

این نسخه «اسکلت واقعی قابل اتصال» است، اما برای انتشار تجاری هنوز باید Backend روی سرور HTTPS مستقر شود، احراز هویت واقعی، ذخیره‌سازی ابری، مدیریت دسترسی فروشگاه‌ها، سیستم تسویه/کمیسیون، سیاست حریم خصوصی و اتصال فروشگاه‌های واقعی اضافه شود.


## نسخه 1.6.0
- داشبورد «استایل هوشمند» برای بررسی کامل بودن کمد
- تشخیص کمبود بالاپوش، شلوار/دامن و کفش
- پیشنهاد خرید برای دسته‌های کمبود
- انتخاب سریع موقعیت و سبک از داشبورد هوشمند
- اصلاح versionCode=6 و versionName=1.6.0
